var searchData=
[
  ['messages_0',['Messages',['../class_media_corner_w_p_f_1_1_view_1_1_users_view.html#a7381fa3ab5c61f9eea109268fd2c2232',1,'MediaCornerWPF::View::UsersView']]],
  ['movieid_1',['MovieId',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_models_1_1_watchlisted_model.html#a5a7df192728fb05d086f49221295904c',1,'MediaCornerWPF::Lib::MongoDB::Models::WatchlistedModel']]],
  ['movieid_2',['movieId',['../class_media_corner_w_p_f_1_1_view_1_1_users_view_1_1_message.html#a02d2661eb696afc53fe0af94f2abfc91',1,'MediaCornerWPF::View::UsersView::Message']]],
  ['movies_3',['Movies',['../class_media_corner_w_p_f_1_1_view_1_1_movie_view.html#af80deeb49c47dfe6bf361ed0cc29f34b',1,'MediaCornerWPF.View.MovieView.Movies'],['../class_media_corner_w_p_f_1_1_view_1_1_watchlist_view.html#ad65064948d880ab35328f1116909b050',1,'MediaCornerWPF.View.WatchlistView.Movies']]],
  ['msg_4',['msg',['../class_media_corner_w_p_f_1_1_view_1_1_users_view_1_1_message.html#a119afd45817979911737a18b4edc8eb9',1,'MediaCornerWPF::View::UsersView::Message']]]
];
