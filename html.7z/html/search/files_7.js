var searchData=
[
  ['settingsview_2eg_2ecs_0',['SettingsView.g.cs',['../_settings_view_8g_8cs.html',1,'']]],
  ['settingsview_2eg_2ei_2ecs_1',['SettingsView.g.i.cs',['../_settings_view_8g_8i_8cs.html',1,'']]],
  ['settingsview_2examl_2ecs_2',['SettingsView.xaml.cs',['../_settings_view_8xaml_8cs.html',1,'']]],
  ['settingsviewmodel_2ecs_3',['SettingsViewModel.cs',['../_settings_view_model_8cs.html',1,'']]]
];
