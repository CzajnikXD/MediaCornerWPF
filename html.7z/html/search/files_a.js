var searchData=
[
  ['watchlistedmodel_2ecs_0',['WatchlistedModel.cs',['../_watchlisted_model_8cs.html',1,'']]],
  ['watchlistview_2eg_2ecs_1',['WatchlistView.g.cs',['../_watchlist_view_8g_8cs.html',1,'']]],
  ['watchlistview_2eg_2ei_2ecs_2',['WatchlistView.g.i.cs',['../_watchlist_view_8g_8i_8cs.html',1,'']]],
  ['watchlistview_2examl_2ecs_3',['WatchlistView.xaml.cs',['../_watchlist_view_8xaml_8cs.html',1,'']]],
  ['watchlistviewmodel_2ecs_4',['WatchlistViewModel.cs',['../_watchlist_view_model_8cs.html',1,'']]]
];
