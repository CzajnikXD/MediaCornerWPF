var searchData=
[
  ['removefromwatchlist_0',['RemoveFromWatchlist',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_d_b.html#a841d78222dcda677c1959616bb283ebd',1,'MediaCornerWPF::Lib::MongoDB::DB']]]
];
