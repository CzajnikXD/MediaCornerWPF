var searchData=
[
  ['textbox_5ftextchanged_0',['TextBox_TextChanged',['../class_media_corner_w_p_f_1_1_view_1_1_users_view.html#a6980844f50b7a69630ade3cf9492b1f1',1,'MediaCornerWPF.View.UsersView.TextBox_TextChanged()'],['../class_media_corner_w_p_f_1_1_view_1_1_watchlist_view.html#a4da123d4ed38bc328dd59cbd651b6df0',1,'MediaCornerWPF.View.WatchlistView.TextBox_TextChanged()']]]
];
