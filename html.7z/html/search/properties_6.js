var searchData=
[
  ['overview_0',['overview',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#ad932689b6450acabb9ed2a039e7066a8',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
