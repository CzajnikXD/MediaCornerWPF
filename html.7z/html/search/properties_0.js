var searchData=
[
  ['_5fid_0',['_id',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_models_1_1_users_model.html#a12ee895580d0a7478ccdf42fd0f837cd',1,'MediaCornerWPF.Lib.MongoDB.Models.UsersModel._id'],['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_models_1_1_watchlisted_model.html#a87ea4a1bc143ef4cb2a1a7d3e994abc1',1,'MediaCornerWPF.Lib.MongoDB.Models.WatchlistedModel._id']]]
];
