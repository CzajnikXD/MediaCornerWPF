var searchData=
[
  ['propertychanged_0',['PropertyChanged',['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_base.html#a3198f3667ecb486554836d5102e14dcb',1,'MediaCornerWPF::ViewModels::ViewModelBase']]]
];
