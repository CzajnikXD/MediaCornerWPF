var searchData=
[
  ['onpropertychanged_0',['OnPropertyChanged',['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_base.html#a018e6c5c296ac0c67c88c844f03741ed',1,'MediaCornerWPF::ViewModels::ViewModelBase']]]
];
