var searchData=
[
  ['caption_0',['Caption',['../class_media_corner_w_p_f_1_1_view_models_1_1_main_menu_window_model.html#a41cfefaaa8d2bb1244dc8cf70361051a',1,'MediaCornerWPF::ViewModels::MainMenuWindowModel']]],
  ['connectionstring_1',['ConnectionString',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_d_b.html#a02656d80d6af010a23927256674b9847',1,'MediaCornerWPF::Lib::MongoDB::DB']]],
  ['currentchildview_2',['CurrentChildView',['../class_media_corner_w_p_f_1_1_view_models_1_1_main_menu_window_model.html#a67ad52ace1697d7ed321e21f6be7b928',1,'MediaCornerWPF::ViewModels::MainMenuWindowModel']]]
];
