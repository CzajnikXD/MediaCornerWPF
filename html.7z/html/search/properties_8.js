var searchData=
[
  ['release_5fdate_0',['release_date',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#aee26f37ce403dbb190b4a0d26b6ccb30',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
