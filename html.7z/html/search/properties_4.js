var searchData=
[
  ['icon_0',['Icon',['../class_media_corner_w_p_f_1_1_view_models_1_1_main_menu_window_model.html#ad9e134c98dd2c6b4bb9a6769b7b4413f',1,'MediaCornerWPF::ViewModels::MainMenuWindowModel']]],
  ['id_1',['Id',['../class_media_corner_w_p_f_1_1_lib_1_1_logged_user.html#aa97c81f57599d38ecc03f2a916260188',1,'MediaCornerWPF::Lib::LoggedUser']]],
  ['id_2',['id',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#a9a8ab31b8d0da0b5a10563d0e7a164af',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
