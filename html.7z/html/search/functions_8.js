var searchData=
[
  ['main_0',['Main',['../class_media_corner_w_p_f_1_1_app.html#a713f271f7a801e3194698b3e9bfb6723',1,'MediaCornerWPF.App.Main()'],['../class_media_corner_w_p_f_1_1_app.html#a713f271f7a801e3194698b3e9bfb6723',1,'MediaCornerWPF.App.Main()']]],
  ['mainmenuwindow_1',['MainMenuWindow',['../class_media_corner_w_p_f_1_1_view_1_1_main_menu_window.html#a78ef6cb12e2305ccb8c7ee4d4f5d4de2',1,'MediaCornerWPF::View::MainMenuWindow']]],
  ['mainmenuwindowmodel_2',['MainMenuWindowModel',['../class_media_corner_w_p_f_1_1_view_models_1_1_main_menu_window_model.html#a10434daebec127cc37a8535cf51821bd',1,'MediaCornerWPF::ViewModels::MainMenuWindowModel']]],
  ['movieview_3',['MovieView',['../class_media_corner_w_p_f_1_1_view_1_1_movie_view.html#a5c17534bbe852fd9587463a9afc7d5d0',1,'MediaCornerWPF::View::MovieView']]]
];
