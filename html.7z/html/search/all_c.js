var searchData=
[
  ['onpropertychanged_0',['OnPropertyChanged',['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_base.html#a018e6c5c296ac0c67c88c844f03741ed',1,'MediaCornerWPF::ViewModels::ViewModelBase']]],
  ['overview_1',['overview',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#ad932689b6450acabb9ed2a039e7066a8',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
