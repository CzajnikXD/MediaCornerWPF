var searchData=
[
  ['addeventhandler_0',['AddEventHandler',['../class_xaml_generated_namespace_1_1_generated_internal_type_helper.html#a73471f4a6d1ca4c4fceec9ad8610f0c8',1,'XamlGeneratedNamespace.GeneratedInternalTypeHelper.AddEventHandler(System.Reflection.EventInfo eventInfo, object target, System.Delegate handler)'],['../class_xaml_generated_namespace_1_1_generated_internal_type_helper.html#a73471f4a6d1ca4c4fceec9ad8610f0c8',1,'XamlGeneratedNamespace.GeneratedInternalTypeHelper.AddEventHandler(System.Reflection.EventInfo eventInfo, object target, System.Delegate handler)']]],
  ['addtowatchlist_1',['AddToWatchlist',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_d_b.html#a9894329dc72cadfe5c9887d9020b397a',1,'MediaCornerWPF::Lib::MongoDB::DB']]],
  ['authorizeuser_2',['AuthorizeUser',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_d_b.html#aeb896b23fb18d7327435f19f1ecfa4e7',1,'MediaCornerWPF::Lib::MongoDB::DB']]]
];
