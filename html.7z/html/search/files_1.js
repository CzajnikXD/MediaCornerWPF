var searchData=
[
  ['apicontroller_2ecs_0',['ApiController.cs',['../_api_controller_8cs.html',1,'']]],
  ['app_2eg_2ecs_1',['App.g.cs',['../_app_8g_8cs.html',1,'']]],
  ['app_2eg_2ei_2ecs_2',['App.g.i.cs',['../_app_8g_8i_8cs.html',1,'']]],
  ['app_2examl_2ecs_3',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_4',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
