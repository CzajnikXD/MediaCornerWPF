var searchData=
[
  ['watchlistcollection_0',['WatchlistCollection',['../class_media_corner_w_p_f_1_1_lib_1_1_mongo_d_b_1_1_d_b.html#a81d05bc31b65d5a01ada80a0c1d3e3f1',1,'MediaCornerWPF::Lib::MongoDB::DB']]]
];
