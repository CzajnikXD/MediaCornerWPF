var searchData=
[
  ['settingsview_0',['SettingsView',['../class_media_corner_w_p_f_1_1_view_1_1_settings_view.html',1,'MediaCornerWPF::View']]],
  ['settingsviewmodel_1',['SettingsViewModel',['../class_media_corner_w_p_f_1_1_view_models_1_1_settings_view_model.html',1,'MediaCornerWPF::ViewModels']]]
];
