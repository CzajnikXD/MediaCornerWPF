var searchData=
[
  ['viewmodelbase_0',['ViewModelBase',['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_base.html',1,'MediaCornerWPF::ViewModels']]],
  ['viewmodelbase_2ecs_1',['ViewModelBase.cs',['../_view_model_base_8cs.html',1,'']]],
  ['viewmodelcommand_2',['ViewModelCommand',['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_command.html',1,'MediaCornerWPF.ViewModels.ViewModelCommand'],['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_command.html#ab3833b89647367bc7a9600373a50503f',1,'MediaCornerWPF.ViewModels.ViewModelCommand.ViewModelCommand(Action&lt; object &gt; executeAction)'],['../class_media_corner_w_p_f_1_1_view_models_1_1_view_model_command.html#a8b1c6700e33f3d88b0d4cd51c803fdf8',1,'MediaCornerWPF.ViewModels.ViewModelCommand.ViewModelCommand(Action&lt; object &gt; executeAction, Predicate&lt; object &gt; canExecuteAction)']]],
  ['viewmodelcommand_2ecs_3',['ViewModelCommand.cs',['../_view_model_command_8cs.html',1,'']]],
  ['vote_5faverage_4',['vote_average',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#a62fa796a5118aec763f6230d560060d2',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
