var searchData=
[
  ['vote_5faverage_0',['vote_average',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#a62fa796a5118aec763f6230d560060d2',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
