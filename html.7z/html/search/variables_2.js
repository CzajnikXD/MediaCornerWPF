var searchData=
[
  ['username_0',['username',['../class_media_corner_w_p_f_1_1_view_models_1_1_main_menu_window_model.html#ad72ecfe47a3d15b601b9a6f98f7042a8',1,'MediaCornerWPF::ViewModels::MainMenuWindowModel']]]
];
