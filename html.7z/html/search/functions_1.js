var searchData=
[
  ['btnclick_0',['btnClick',['../class_media_corner_w_p_f_1_1_view_1_1_movie_view.html#ab5262125bf286af6ec096aeeeb181e24',1,'MediaCornerWPF.View.MovieView.btnClick()'],['../class_media_corner_w_p_f_1_1_view_1_1_users_view.html#a3d45e0a6b467b1314ebe44bf0ea47d25',1,'MediaCornerWPF.View.UsersView.btnClick()'],['../class_media_corner_w_p_f_1_1_view_1_1_watchlist_view.html#a4c0f2a63d6f69082b5cbd185c29b3ffc',1,'MediaCornerWPF.View.WatchlistView.btnClick()']]],
  ['btnclose_5fclick_1',['btnClose_Click',['../class_media_corner_w_p_f_1_1_view_1_1_login_view.html#afa8e81eea857bfd0b5b0554ac5488c68',1,'MediaCornerWPF.View.LoginView.btnClose_Click()'],['../class_media_corner_w_p_f_1_1_view_1_1_main_menu_window.html#a07ac55fff27c97b93348d098c3fa49eb',1,'MediaCornerWPF.View.MainMenuWindow.btnClose_Click()']]],
  ['btnlogin_5fclick_2',['btnLogin_Click',['../class_media_corner_w_p_f_1_1_view_1_1_login_view.html#a77f73d7428b13d41ea6da50055e68875',1,'MediaCornerWPF::View::LoginView']]],
  ['btnmaximize_5fclick_3',['btnMaximize_Click',['../class_media_corner_w_p_f_1_1_view_1_1_main_menu_window.html#a13507d24f5d53f27b32acc5ea7b03113',1,'MediaCornerWPF::View::MainMenuWindow']]],
  ['btnminimize_5fclick_4',['btnMinimize_Click',['../class_media_corner_w_p_f_1_1_view_1_1_login_view.html#abe0cad1c026481ac583f6a03d8e84e89',1,'MediaCornerWPF.View.LoginView.btnMinimize_Click()'],['../class_media_corner_w_p_f_1_1_view_1_1_main_menu_window.html#a13be802037762309fc817a59268f5699',1,'MediaCornerWPF.View.MainMenuWindow.btnMinimize_Click()']]]
];
