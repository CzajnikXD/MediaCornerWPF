var searchData=
[
  ['popularmovies_0',['PopularMovies',['../class_media_corner_w_p_f_1_1_view_1_1_main_menu_window.html#ab26313a34e6f64f10c682826aa884668',1,'MediaCornerWPF::View::MainMenuWindow']]]
];
