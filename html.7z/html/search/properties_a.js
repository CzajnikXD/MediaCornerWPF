var searchData=
[
  ['title_0',['title',['../class_media_corner_w_p_f_1_1_lib_1_1_a_p_i_1_1_models_1_1_movie_model.html#aba0bfbc6af57c8595b8b7f9c6aedfc0d',1,'MediaCornerWPF::Lib::API::Models::MovieModel']]]
];
